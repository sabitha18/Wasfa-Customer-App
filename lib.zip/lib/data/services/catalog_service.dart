import '../../core/network/api_client.dart';
import '../../core/network/api_config.dart';
import '../../core/network/api_exception.dart';
import '../models/area_catalog.dart';
import '../models/coupon_result.dart';
import '../models/home_feed.dart';
import '../models/pharmacy_store.dart';
import '../models/product.dart';

/// Anonymous browsing endpoints — home feed, product listing/detail, areas,
/// coupon check. None of these require `user_id`.
class CatalogService {
  CatalogService._();
  static final CatalogService instance = CatalogService._();
  final ApiClient _client = ApiClient.instance;

  Future<HomeFeed> home() async {
    final res = await _client.get(ApiConfig.home);
    return HomeFeed.fromJson(res as Map<String, dynamic>);
  }

  /// Product listing (PLP). All filters optional, matching the query params
  /// documented on the "Product listing" request.
  Future<ProductPage> products({
    String query = '',
    String? category,
    String? brand,
    String sort = 'pop',
    bool inStock = false,
    int page = 1,
    int perPage = 24,
    int? shop, // filter to a single store's catalogue (store id = shop user_id)
  }) async {
    final res = await _client.get(ApiConfig.products, query: {
      'q': query,
      'category': category,
      'brand': brand,
      'sort': sort,
      if (inStock) 'in_stock': 1,
      if (shop != null) 'shop': shop,
      'page': page,
      'per_page': perPage,
    });
    return ProductPage.fromJson(res as Map<String, dynamic>);
  }

  Future<Product> product(String sku) async {
    final res = await _client.get(ApiConfig.product(sku));
    return Product.fromJson(res as Map<String, dynamic>);
  }

  /// Store marketplace list (home "Nearest / Browse all stores").
  ///
  /// ⚠ `GET /app/stores` is NOT implemented server-side yet — it currently
  /// returns an empty list. This method is future-proofed for the shapes
  /// `{ stores: [...] }` / `{ data: [...] }` / a bare array, and simply
  /// returns `[]` until the endpoint ships (the Home screen then shows its
  /// empty state rather than any invented data).
  Future<List<PharmacyStore>> stores() async {
    final res = await _client.get(ApiConfig.stores);
    final list = (res is Map ? res['stores'] ?? res['data'] ?? res['items'] : null) ?? (res is List ? res : const []);
    return (list as List).map((e) => PharmacyStore.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<AreaCatalog> areas() async {
    final res = await _client.get(ApiConfig.areas);
    return AreaCatalog.fromJson(res as Map<String, dynamic>);
  }

  Future<CouponResult> checkCoupon({required String code, required double subtotal}) async {
    final res = await withFallbackMessage(
      () => _client.get(ApiConfig.coupon, query: {
        'code': code,
        'subtotal': subtotal.toStringAsFixed(3),
      }),
      'That coupon code doesn\'t seem to work.',
    );
    return CouponResult.fromJson(res as Map<String, dynamic>, requestedCode: code);
  }
}

/// `GET /app/products` → `{ total, page, per_page, pages, items[] }`.
class ProductPage {
  final int total;
  final int page;
  final int perPage;
  final int pages;
  final List<Product> items;

  const ProductPage({required this.total, required this.page, required this.perPage, required this.pages, required this.items});

  static const empty = ProductPage(total: 0, page: 1, perPage: 24, pages: 0, items: []);

  factory ProductPage.fromJson(Map<String, dynamic> json) => ProductPage(
        total: (json['total'] as num?)?.toInt() ?? 0,
        page: (json['page'] as num?)?.toInt() ?? 1,
        perPage: (json['per_page'] as num?)?.toInt() ?? 24,
        pages: (json['pages'] as num?)?.toInt() ?? 1,
        items: ((json['items'] as List?) ?? const [])
            .map((e) => Product.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}
