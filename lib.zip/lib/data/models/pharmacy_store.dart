import 'package:flutter/material.dart';
import '../../core/utils/json_utils.dart';

class PharmacyStore {
  /// Backend store id from `GET /app/stores` — this is the shop's `user_id`,
  /// and the value the product listing expects as `?shop=<id>` to filter to
  /// just this store's catalogue. Null for the local mock stores.
  final int? id;
  final String name;
  final String nameAr;
  final String area;
  final String category; // pharmacy, beauty, eyecare, nutrition
  final String eta; // "20-30"
  final bool fast;
  final bool pro;
  final bool freeDelivery;
  final String? offer; // "60% off"
  final String seller; // maps to Seller.name used across PRODUCTS
  final List<Color> gradient;
  final String monogram;

  const PharmacyStore({
    this.id,
    required this.name,
    required this.nameAr,
    required this.area,
    required this.category,
    required this.eta,
    required this.fast,
    required this.pro,
    required this.freeDelivery,
    this.offer,
    required this.seller,
    required this.gradient,
    required this.monogram,
  });

  String label(bool arabic) => arabic ? nameAr : name;

  /// From `GET /app/stores` list items. The endpoint is not yet implemented
  /// server-side (returns empty for now) — field names below are best-effort
  /// candidates; confirm and trim once `AppCatalogController@stores` ships.
  ///
  /// Visual-only fields the API won't carry (a brand `gradient` and a
  /// `monogram`) are derived locally so the existing store cards render
  /// without any server-side design metadata.
  factory PharmacyStore.fromJson(Map<String, dynamic> json) {
    final name = asString(json, const ['name', 'store_name', 'title']);
    final monogram = asString(json, const ['monogram']);
    return PharmacyStore(
      // The shop's `user_id` — sent back as `?shop=<id>` to filter products.
      id: asIntOrNull(json, const ['id', 'user_id', 'store_id', 'seller_id']),
      name: name,
      nameAr: asString(json, const ['name_ar', 'arabic_name'], fallback: name),
      area: asString(json, const ['area', 'area_name']),
      category: asString(json, const ['category', 'type'], fallback: 'pharmacy'),
      eta: asString(json, const ['eta', 'delivery_eta'], fallback: '30-45'),
      fast: asBool(json, const ['fast']),
      pro: asBool(json, const ['pro']),
      // Default to free delivery when the flag is absent, matching the mock UI.
      freeDelivery: (json.containsKey('free_delivery') || json.containsKey('freeDelivery'))
          ? asBool(json, const ['free_delivery', 'freeDelivery'])
          : true,
      offer: asStringOrNull(json, const ['offer', 'offer_label']),
      seller: asString(json, const ['seller', 'seller_name', 'name']),
      gradient: _gradientFor(name),
      monogram: monogram.isNotEmpty ? monogram : (name.isNotEmpty ? name[0].toUpperCase() : '℞'),
    );
  }

  static const List<List<Color>> _paletteGradients = [
    [Color(0xFF7C5CFF), Color(0xFF1E9CD7)],
    [Color(0xFF023B60), Color(0xFF1E9CD7)],
    [Color(0xFF0B6B4F), Color(0xFF23B487)],
    [Color(0xFF7A1F1F), Color(0xFFB34B4B)],
    [Color(0xFF0E3554), Color(0xFF1E9CD7)],
    [Color(0xFFE7609F), Color(0xFFF6A5C0)],
  ];

  /// Deterministic gradient per store so the same store always looks the same.
  static List<Color> _gradientFor(String key) {
    if (key.isEmpty) return _paletteGradients.first;
    return _paletteGradients[key.hashCode.abs() % _paletteGradients.length];
  }
}

class StoreCategory {
  final String key;
  final String emoji;
  final String labelEn;
  final String labelAr;
  const StoreCategory(this.key, this.emoji, this.labelEn, this.labelAr);
}
